<?php

$jugadorActual = 0;


?>