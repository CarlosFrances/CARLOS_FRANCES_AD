//Objetos en el formulario
var contenedorTiempo, contenedorUsuario, lineaTiempo;

//Cuando la ventana se cargue, captura el contenedor del tiempo, del usuario, y la línea de tiempo
window.onload = function(){
    contenedorTiempo = document.getElementById("mazoTiempo");
    contenedorUsuario = document.getElementById("mazoUsuario");
    lineaTiempo = document.getElementById("lineaTiempo");
}
